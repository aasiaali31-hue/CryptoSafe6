package com.cryptosafe.app;

import android.os.Bundle;
import android.widget.*;
import android.graphics.Color;
import android.view.Gravity;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32, 40, 32, 32);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.rgb(17,24,39));

        TextView title = new TextView(this);
        title.setText("CryptoSafe");
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0,0,0,30);

        TextView info = new TextView(this);
        info.setText("محفظتك الرقمية تبدأ بالأمان\n\nهذا الإصدار الأول من CryptoSafe.\nلا تدخل عبارة الاسترداد أو المفاتيح الخاصة في أي مكان.");
        info.setTextColor(Color.WHITE);
        info.setTextSize(18);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0,0,0,30);

        Button start = new Button(this);
        start.setText("بدء الاستخدام");
        start.setOnClickListener(v ->
            Toast.makeText(this, "CryptoSafe جاهز للعمل", Toast.LENGTH_SHORT).show()
        );

        root.addView(title, new LinearLayout.LayoutParams(-1, -2));
        root.addView(info, new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(start, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
    }
}
